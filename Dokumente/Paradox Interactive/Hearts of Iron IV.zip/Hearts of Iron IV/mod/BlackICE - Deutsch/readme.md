Übersetzung für den BlackICE mod (BlackICE Historical Immersion Mod - 8.0.3)

https://steamcommunity.com/sharedfiles/filedetails/?id=1137372539

Mein Dank geht an die tolle Arbeit der BlackICE Entwickler.

History

2023-06-23		7.0.2-pre1		Automatische Übersetzung.
2023-06-28		7.0.2-pre2		Alle Icons wurden korrigiert.
2023-07-02		7.0.2-pre3		Alle Variablen wurden korrigiert.
2023-07-06		7.0.2-pre4		Die meisten Farbcodierungen wurden korrigiert.
2023-07-08		7.0.2			Die erste vollständig übersetzte Version.
2023-07-10		7.0.2.1			Über 200 kleinere Änderungen.
2023-07-12		7.0.2.2 		Die Datei trm_tank_modules_l_german (3044 Zeilen) ist jetzt auch auf deutsch.
								Und wieder mehr als 100 kleinere Änderungen.
2023-07-14		7.0.2.3			Über 150 kleinere Änderungen.
2023-07-28		7.0.2.4			Über 300 kleinere Änderungen.
2023-08-27		7.0.2.5			Über 500 kleinere Änderungen.

2023-10-28		8.0.1-pre1		Anpassungen an Version 8.0.1
2023-10-30		8.0.1-pre2		Über 500 kleinere Änderungen.
2023-11-03		8.0.1-pre3		Über 400 kleinere Änderungen.
2023-11-10 		8.0.1			Über 350 kleinere Änderungen.

2023-12-31		8.0.3			Anpassungen an Version 8.0.3. (Über 2000 kleinere Änderungen)

Roadmap:

8.0.x			Ich werde komische und oder falsche Übersetzungen koriegiern.
				Das wird allerdings eine Weile dauern da ich das nur beim Spielen herausfinden kann ... *g*
				Gerne dürft ihr mir auch Übersetzungen posten welche eurer Meinung nach nicht korrekt sind.

Alle 8.0.x-Versionen sind SaveGame kompatibel.