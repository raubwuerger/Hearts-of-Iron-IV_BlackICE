Übersetzung für den BlackICE mod (BlackICE Historical Immersion Mod - 8.1.0)

https://steamcommunity.com/sharedfiles/filedetails/?id=1137372539

Mein Dank geht an die tolle Arbeit der BlackICE Entwickler.

History

2024-09-28		8.1.1.1			Anpassungen an Version 8.1.1
2024-08-04		8.1.0.5			Viele kleine Korrekturen hinzugefügt
2024-07-21		8.1.0.4			Viele kleine Korrekturen hinzugefügt
2024-05-30		8.1.0.3			Fehlende deutsche Schlüssel wieder hinzugefügt
2024-05-19		8.1.0.2			Weitere Anpassungen an Version 8.1.0 (Über 1500 kleinere Änderungen)
2024-04-02		8.1.0.1			Weitere Anpassungen an Version 8.1.0
2024-03-18		8.1.0.0			Anpassungen an Version 8.1.0
2024-02-17 		8.0.3.2			Schiffsdateien nochmal überarbeitet und weitere Änderungen.
2024-01-02		8.0.3.1			Schiffsdateien überarbeitet.
2023-12-31		8.0.3			Anpassungen an Version 8.0.3. (Über 2000 kleinere Änderungen)
2023-11-10 		8.0.1			Über 350 kleinere Änderungen.
2023-11-03		8.0.1-pre3		Über 400 kleinere Änderungen.
2023-10-30		8.0.1-pre2		Über 500 kleinere Änderungen.
2023-10-28		8.0.1-pre1		Anpassungen an Version 8.0.1


Roadmap:

8.0.x			Ich werde komische und oder falsche Übersetzungen koriegiern.
				Das wird allerdings eine Weile dauern da ich das nur beim Spielen herausfinden kann ... *g*
				Gerne dürft ihr mir auch Übersetzungen posten welche eurer Meinung nach nicht korrekt sind.

Alle 8.x-Versionen sind SaveGame kompatibel.