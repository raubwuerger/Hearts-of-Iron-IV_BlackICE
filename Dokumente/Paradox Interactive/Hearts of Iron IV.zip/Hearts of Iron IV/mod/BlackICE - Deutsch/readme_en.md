Translation for the BlackICE mod (BlackICE Historical Immersion Mod - 8.0.3)

https://steamcommunity.com/sharedfiles/filedetails/?id=1137372539

My thanks go to the great work of the BlackICE developers.

History

2023-06-23		7.0.2-pre1		Automatic translation.
2023-06-28		7.0.2-pre2		All icons have been corrected.
2023-07-02		7.0.2-pre3		All variables have been corrected.
2023-07-06		7.0.2-pre4		Most color coding has been corrected.
2023-07-08		7.0.2			The first fully translated version.
2023-07-10		7.0.2.1			Over 200 minor changes.
2023-07-12		7.0.2.2			The file trm_tank_modules_l_german (3044 lines) is now also in German.
								And again more than 100 minor changes.
2023-07-14		7.0.2.3			Over 150 minor changes.
2023-07-28		7.0.2.4			Over 300 minor changes.
2023-08-27		7.0.2.5			Over 500 minor changes.

2023-10-28		8.0.1-pre1 		Adjustments to version 8.0.1
2023-10-30		8.0.1-pre2 		Over 500 minor changes.
2023-11-03		8.0.1-pre3		Over 400 minor changes.
2023-11-10		8.0.1			Over 350 minor changes.

2023-12-31		8.0.3			Adjustments to version 8.0.3. (Over 2000 minor changes)

Roadmap:

8.0.x 			I will correct strange and/or incorrect translations.
				This will take a while though as I can only find out by playing... *g*
				You are also welcome to post me translations that you think are incorrect.

All 8.0.x versions are SaveGame compatible.