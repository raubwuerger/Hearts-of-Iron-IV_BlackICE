version="9.0.5.1"
tags={
	"Translation"
}
name="BlackICE - Deutsch"
supported_version="1.16.*"
path="D:/Spiele/SteamLibrary/steamapps/workshop/content/394360/2993385538"
remote_file_id="2993385538"