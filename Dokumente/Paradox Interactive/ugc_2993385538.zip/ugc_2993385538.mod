version="8.1.1.3"
tags={
	"Translation"
}
name="BlackICE - Deutsch"
supported_version="1.14.8"
path="D:/SteamLibrary/steamapps/workshop/content/394360/2993385538"
remote_file_id="2993385538"