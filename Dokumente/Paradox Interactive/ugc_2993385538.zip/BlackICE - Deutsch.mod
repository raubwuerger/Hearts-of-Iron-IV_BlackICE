version="8.1.6.1"
tags={
	"Translation"
}
name="BlackICE - Deutsch"
supported_version="1.14.10"
path="C:/Users/jha/Documents/Paradox Interactive/Hearts of Iron IV/mod/BlackICE - Deutsch"
remote_file_id="2993385538"