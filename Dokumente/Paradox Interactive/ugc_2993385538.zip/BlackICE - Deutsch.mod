version="9.0.5.2"
tags={
	"Translation"
}
name="BlackICE - Deutsch"
supported_version="1.16.*"
path="C:/Users/jha/Documents/Paradox Interactive/Hearts of Iron IV/mod/BlackICE - Deutsch"
remote_file_id="2993385538"