Translation for the BlackICE mod (BlackICE Historical Immersion Mod - 8.1.1)

https://steamcommunity.com/sharedfiles/filedetails/?id=1137372539

My thanks go to the great work of the BlackICE developers.

History

2024-10-18		8.1.1.3			Error in file equipment_l_german.yml fixed. Cause of missing equipment texts.
2024-10-16		8.1.1.2			Over 100 minor changes.
2024-09-28		8.1.1.1			Adjustments to version 8.1.1
2024-08-04		8.1.0.5			Many small corrections added
2024-07-21		8.1.0.4			Many small corrections added
2024-05-30		8.1.0.3			Missing German keys added again
2024-05-19		8.1.0.2			Further adjustments to version 8.1.0 (over 1500 minor changes)
2024-04-02		8.1.0.1			Further adjustments to version 8.1.0
2024-03-18		8.1.0.0			Adjustments to version 8.1.0
2024-02-17 		8.0.3.2 		Ship files revised again and other changes.
2024-01-02 		8.0.3.1 		Ship files revised.
2023-12-31 		8.0.3 			Adjustments to version 8.0.3 (over 2000 minor changes)
2023-11-10 		8.0.1 			Over 350 minor changes.
2023-11-03 		8.0.1-pre3 		Over 400 minor changes.
2023-10-30 		8.0.1-pre2 		Over 500 minor changes.
2023-10-28 		8.0.1-pre1 		Adjustments to version 8.0.1


Roadmap:

8.0.x 			I will correct strange and/or incorrect translations.
				This will take a while though as I can only find out by playing... *g*
				You are also welcome to post me translations that you think are incorrect.

All 8.x versions are SaveGame compatible.