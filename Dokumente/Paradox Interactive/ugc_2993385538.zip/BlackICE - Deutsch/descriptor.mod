version="8.1.6.1"
tags={
	"Translation"
}
name="BlackICE - Deutsch"
supported_version="1.14.10"
remote_file_id="2993385538"