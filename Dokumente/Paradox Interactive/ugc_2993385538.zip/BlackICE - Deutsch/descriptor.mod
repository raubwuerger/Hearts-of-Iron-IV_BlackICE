version="9.1.1.1"
tags={
	"Translation"
}
name="BlackICE - Deutsch"
supported_version="1.16.*"
remote_file_id="2993385538"